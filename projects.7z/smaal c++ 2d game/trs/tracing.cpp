#include<iostream>
#include<conio.h>
using namespace std;
///////////////////
void Mat(char x[][160])
{
	int r,c;

	for(r=0;r<24;r++)
	{
		for(c=0;c<160;c++)
		{
			x[r][c]=' ';
		}
	}

	for (int c=1; c< 79; c++)
	{
		x[0][c] = 196;
		x[23][c] = 196;
	}


	for (int r=1; r< 23; r++)
	{
		x[r][0]  = 179;
		x[r][79] = 179;
	}

	x[0][79]=187;
	x[0][0]=214;
	x[23][79]=188;
	x[23][0]=200;


}
///////////////////
void cout_screen(char x[][160], int cHero)
{
	system("cls");

	if(cHero>40&&cHero+40<160)
	{
	for (int r=0; r< 24; r++)
	{
		for (int c=cHero-40; c< cHero+40; c++)
		{
			cout<<x[r][c];
		}
	}
	}
	else if(cHero<40)
	{
			for (int r=0; r< 24; r++)
	{
		for (int c=0; c< 80; c++)
		{
			cout<<x[r][c];
		}
	}
	}
	else if(cHero>120)
	{
		for (int r=0; r< 24; r++)
		{
		for (int c=80; c< 160; c++)
		{
			cout<<x[r][c];
		}
		}
	}
}
//////////////////////
void Hero(char x[][160] , int rHero, int cHero,int &flagH,int &flagD,int &flagG,int &flagS,int &flagY)
{
	if(flagH==0)
	{
		if(flagG==0)
		{
		if(flagD==0 || flagD==1 || flagD==2)
		{
	       x[rHero][cHero] = 'O';
	       x[rHero+1][cHero-1] ='/'; 
	       x[rHero+1][cHero] ='|';
	       x[rHero+1][cHero+1] = '\\';                   //////////////////////flagSSSSSSSSSSSSS
	       x[rHero+2][cHero-1] = '/';
	       x[rHero+2][cHero+1] = '\\';
		}
		}

		if(flagG==1)
		{
			if(flagD==0 || flagD==1)
			{
			    x[rHero][cHero] = 'O';
        	    x[rHero+1][cHero-1] ='/'; 
	            x[rHero+1][cHero] ='|';
	            x[rHero+1][cHero+1] = '\\';
			    x[rHero+1][cHero+2]=169;
        	    x[rHero+2][cHero-1] = '/';
        	    x[rHero+2][cHero+1] = '\\';
			}
		   if(flagD==2)
	       {
		    	x[rHero][cHero] = 'O';
	            x[rHero+1][cHero-1] ='/'; 
			    x[rHero+1][cHero-2]=170;
	            x[rHero+1][cHero] ='|';
	            x[rHero+1][cHero+1] = '\\';
	            x[rHero+2][cHero-1] = '/';
        	    x[rHero+2][cHero+1] = '\\';

		   }
		}
	}
	if(flagH==1)
	{
		if(flagD==1 || flagD==0)
		{
	        x[rHero+2][cHero]='_';
	    	x[rHero+2][cHero+1]=220;
		    x[rHero+2][cHero+2]='*';
		}
		if(flagD==2 || flagD==0)
		{
			x[rHero+2][cHero]='*';
	    	x[rHero+2][cHero+1]=220;
		    x[rHero+2][cHero+2]='_';
		}

	}
	if(flagH==2)
	{
		if(flagS==0)
		{
			if(flagY==0 || flagY==1)
			{
		         if(flagD==1 || flagD==0)
		         {
	                 x[rHero][cHero] = 16;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
	                 x[rHero+1][cHero-1] = '<';
	                 x[rHero+2][cHero] = 33;
		         }
		         if(flagD==2 || flagD==0)
		         {
		         	x[rHero][cHero] = 17;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
	                 x[rHero+1][cHero-1] = '<';
	                 x[rHero+2][cHero] = 33;
		         }
			}
		}


		if(flagS==1)
		{
			if(flagY==1)
			{
		        if(flagD==1 || flagD==0)
		         {
	                 x[rHero][cHero] = 16;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
					 x[rHero+1][cHero+2] = 196;
					 x[rHero+1][cHero+3] = '>';
	                 x[rHero+1][cHero-1] = '<';
	                 x[rHero+2][cHero] = 33;
					 x[rHero+1][cHero+4]=' ';
	    		     x[rHero+1][cHero+5]=' ';
		         }
		         if(flagD==2 || flagD==0)
		         {
		         	x[rHero][cHero] = 17;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
	                 x[rHero+1][cHero-1] = '<';
					 x[rHero+1][cHero-2] = 196;
					 x[rHero+1][cHero-3] = '<';
	                 x[rHero+2][cHero] = 33;
					 x[rHero+1][cHero-4]=' ';
	    		     x[rHero+1][cHero-5]=' ';
		         }
			}

			if(flagY==0)
			{
		         if(flagD==1 || flagD==0)
		         {
	                 x[rHero][cHero] = 16;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
	                 x[rHero+1][cHero-1] = '<';
	                 x[rHero+2][cHero] = 33;
				 }
		         if(flagD==2 || flagD==0)
		         {
		         	x[rHero][cHero] = 17;
	                 x[rHero+1][cHero] = 219;
	                 x[rHero+1][cHero+1] = '>';
	                 x[rHero+1][cHero-1] = '<';
	                 x[rHero+2][cHero] = 33;
		         }
			}

		}
	
	}

	if(flagH==3)
	{
		if(flagG==0)
		{
		     if(flagD==0 || flagD==1 )
		     {
	          
				x[rHero+1][cHero-1] = '_';
				x[rHero+1][cHero-1] = '|';
				x[rHero+1][cHero] = '|';			
				x[rHero+2][cHero+1] = '_';
				x[rHero+1][cHero+2] = '_';
				x[rHero+1][cHero+1] = 205;
				x[rHero+1][cHero+2] = 205;
				x[rHero+1][cHero+3] = 205;
				x[rHero+1][cHero+4] = 205;				
				x[rHero+1][cHero-2]='_';
				x[rHero+2][cHero-2]='\\';
				x[rHero+2][cHero]='o';
				x[rHero+2][cHero-1]='o';
				x[rHero+2][cHero+1]='o';
				x[rHero+2][cHero+2]='/';
	            
				
		     }
			 if(flagD==2)
			 {
				x[rHero+1][cHero] = '|';
				x[rHero+1][cHero+1] = '|';			
				x[rHero+2][cHero+1] = '_';
				x[rHero+1][cHero-1] = 205;	
				x[rHero+1][cHero-2] = 205;
				x[rHero+1][cHero-3] = 205;
				x[rHero+1][cHero-4] = 205;				
				x[rHero+1][cHero+2]='_';
				x[rHero+2][cHero-2]='\\';
				x[rHero+2][cHero]='o';
				x[rHero+2][cHero-1]='o';
				x[rHero+2][cHero+1]='o';
				x[rHero+2][cHero+2]='/';
			 }
		}    
	}

	if(flagH==4)
	{
		x[rHero][cHero]='O';
		x[rHero+1][cHero]='M';
		x[rHero+1][cHero+1]='\\';	
		x[rHero+1][cHero-1]='/';
		x[rHero+1][cHero-2]='|';
		x[rHero+2][cHero-2]='|';
		x[rHero+3][cHero-2]='|';
		x[rHero][cHero-2]='$';
		x[rHero+2][cHero]='|';
		x[rHero+3][cHero+1]='\\';
		x[rHero+3][cHero-1]='/';

	}

	if(rHero==17 && cHero==76 || rHero==16 && cHero==76 || rHero==15 && cHero==76 || rHero==14 && cHero==76 || rHero==13 && cHero==76
	   || rHero==17 && cHero==75 || rHero==16 && cHero==75 || rHero==15 && cHero==75 || rHero==14 && cHero==75 || rHero==13 && cHero==75
	   || rHero==11 && cHero==4 || rHero==10 && cHero==4 || rHero==9 && cHero==4 || rHero==8 && cHero==4 || rHero==7 && cHero==4 || rHero==6 && cHero==4
	   || rHero==11 && cHero==3 || rHero==10 && cHero==3 || rHero==9 && cHero==3 || rHero==8 && cHero==3 || rHero==7 && cHero==3 || rHero==6 && cHero==3 
	   || x[rHero-1][cHero]=='=')

	   
		{
			x[rHero][cHero] = '*';
			x[rHero][cHero-1] = '\\';
			x[rHero][cHero+1] = '/';
		    x[rHero+1][cHero] = 219;			
		    x[rHero+2][cHero+1] = '\\';
		    x[rHero+2][cHero-1] = '/';	
			x[rHero+2][cHero] = ' ';	
		    
		}
}
//////////////////////
void Hero_Damage(char x[][160],int &rHero,int &cHero,int &H)
{
	for(int c=10;c<63;c++)
	{
		if(rHero== 19 && cHero == c)
		{
			H=0;
			rHero=17;
			cHero=7;
		}
	}
}
//////////////////////
void gravity(int &cHero, int &rHero,char x[][160],int &flagH,int flag22)
{
	if(flagH==0&&flag22!=0)
	{
	
	     if(x[rHero+3][cHero]==' '&&x[rHero+3][cHero+1]==' '&&x[rHero+3][cHero-1]==' '&&x[rHero+2][cHero+2]==' '&&x[rHero+2][cHero-2]==' ')
	     {
	 	     rHero++;
	     }
	}
	if(flagH==1)
	{
		if(x[rHero+3][cHero]==' '&&x[rHero+3][cHero+1]==' '&&x[rHero+3][cHero+2]==' ')
	    {
		  
			rHero++;  ////////////***cat
	    }
	}

	if(flagH==2)
	{
		if(x[rHero+3][cHero]==' ')
	    {
		    rHero++; 
	    }/////////////////**robot
	}
	if(flagH==3)
	{
		if(x[rHero+3][cHero]==' ')
	    {
		    rHero++; 
	    }
	}

	if(flagH==4)
	{
		if(x[rHero+4][cHero]==' ')
		{
			rHero++;
		}
	}
}
//////////////////////
void move(int &cHero, int &rHero,char press,char x[][160],int &flagH,int &ctH,int &ctH1,int &flagD,int &ctH2,int &flagG,int &flagS,int &ctH3,int &flagY,int &flagSS,int &flagW,int &rr,int &cc,int &ctH5,int i)
{
	if(press=='w'||press=='W')
	{
		if(flagH!=3)
		{
		if(x[rHero-1][cHero]==' '||x[rHero-1][cHero]=='|'||x[rHero-1][cHero]=='-')
		{
			
	     	if(x[rHero+3][cHero]!=' '||x[rHero-1][cHero]=='|'||x[rHero-1][cHero]=='-')
		    {
		     	cout<<"good";
		        if(rHero>1)
		        {
		            rHero--;
		        }
		    }
		}
		}
	}

	if(press=='s'||press=='S')
	{
		if(flagH==0 || flagH==2 )
		{
		if(x[rHero+3][cHero]==' '||x[rHero+3][cHero]=='|'||x[rHero+3][cHero]=='-')
		{
	    	if(rHero<20)
		    {
		        rHero++;
		    }
		}
		}
		if(flagH==1)
		{
			if(x[rHero+3][cHero+1]==' '||x[rHero+3][cHero+1]=='|'||x[rHero+3][cHero+1]=='-')
		{
	    	if(rHero<20)
		    {
		        rHero++;
		    }
		}  ////////***cat
		}
	}

	if(press=='d'||press=='D')
	{
		flagD=1;
		if(flagH==0||flagH==2 || flagH==4)
		{
		   
		        if(x[rHero][cHero+3]==' '||x[rHero][cHero+3]=='|'||x[rHero][cHero+3]=='-')
		        {
		           if(cHero<160)
		           {
		               cHero++;
		           }
		        }
			
		}

		if(flagH==1)
		{
			if(x[rHero+2][cHero+3]==' '||x[rHero+2][cHero+3]=='|'||x[rHero+2][cHero+3]=='-'||x[rHero+2][cHero+3]=='_')
		        {
		           if(cHero<77)
		           {
		               cHero++;
		           }
		        }  ////////***cat
		}

		if(flagH==3)
		{
		        if(x[rHero+1][cHero+5]==' ')
		        {
		           if(cHero<77)
		           {
		               cHero++;
		           }
		        }
			
		}
	}

	if(press=='a'||press=='A')
	{
		flagD=2;
		if(flagH==0||flagH==2 || flagH==4)
		{
		
		    if(x[rHero][cHero-3]==' '||x[rHero][cHero-3]=='|'||x[rHero][cHero-3]=='-')
		    {
			
		        if(cHero>2)
		        {
		            cHero--;
		        }
		    }
		
		}
		if(flagH==1)
		{
			 if(x[rHero+2][cHero-1]==' '||x[rHero+2][cHero-1]=='|'||x[rHero+2][cHero-1]=='-')
		    {
			
		        if(cHero>2)
		        {
		            cHero--;
		        }
		    }  ////////***cat
		}

		if(flagH==3)
		{
		        if(x[rHero+1][cHero-5]==' ')
		        {
		           if(cHero>2)
		           {
		               cHero--;
		           }
		        }
			
		}

		
	}

	if(press==' ')
	{
		
		if(flagH==0 || flagH==2 || flagH==4)
		{
		 if(x[rHero+3][cHero]!=' '||x[rHero+3][cHero+1]!=' '||x[rHero+3][cHero-1]!=' ')
	     {
	         if(rHero>2&&x[rHero-3][cHero]==' '&&x[rHero-2][cHero]==' '&&x[rHero-1][cHero]==' ')
	         {
	             rHero-=3;

	         }

		     if(rHero>2&&x[rHero-3][cHero]!=' '&&x[rHero-2][cHero]==' '&&x[rHero-1][cHero]==' ')
	         {
	             rHero-=2;
	         } 

			if(rHero>2&&x[rHero-2][cHero]!=' '&&x[rHero-1][cHero]==' ')
	        {
	             rHero-=1;
	        }  
	    }
		}
		if(flagH==1)
		{
			if(x[rHero+3][cHero+1]!=' '||x[rHero+3][cHero+2]!=' '||x[rHero+3][cHero]!=' ')
	     {
	         if(rHero>2&&x[rHero+1][cHero+1]==' '&&x[rHero][cHero+1]==' '&&x[rHero-1][cHero+1]==' '&&x[rHero+1][cHero]==' '&&x[rHero][cHero]==' '&&x[rHero-1][cHero]==' '&&x[rHero+1][cHero-1]==' '&&x[rHero][cHero-1]==' '&&x[rHero-1][cHero-1]==' ')
	         {
	             rHero-=3;
	         }

		     if(rHero>2&&x[rHero-1][cHero+1]!=' '&&x[rHero][cHero+1]==' '&&x[rHero+1][cHero+1]==' '&&x[rHero-1][cHero]!=' '&&x[rHero][cHero]==' '&&x[rHero+1][cHero]==' '&&x[rHero-1][cHero-1]!=' '&&x[rHero][cHero-1]==' '&&x[rHero+1][cHero-1]==' ')
	         {
	             rHero-=2;
	         } 

			if(rHero>2&&x[rHero][cHero+1]!=' '&&x[rHero+1][cHero+1]==' '&&x[rHero][cHero]!=' '&&x[rHero+1][cHero]==' '&&x[rHero][cHero-1]!=' '&&x[rHero+1][cHero-1]==' ')
	        {
	             rHero-=1;
	        }  
	    }
		}
		
	
	}

	/////////////////Transformation
	if(press=='1')
	{
		ctH++;
		if(ctH%2!=0)
		{
		   flagH=1;
		}
		else
		{
			flagH=0;
		}
	}
	if(press=='2')
	{
		ctH1++;
	    if(ctH1%2!=0)
		{
			flagH=2;
		}
		else
		{
			flagH=0;
		}

	}
	if(press=='3')
	{
		ctH2++;
		if(ctH2%2!=0)
		{
			flagG=1;
		}
		else
		{
			flagG=0;
		}

	}

	

	if(press=='4')
	{
		ctH3++;
		if(ctH3%2!=0)
		{
			flagY=1;
		}
		else
		{
			flagY=0;
		}
	}

	if(press=='5')
	{
		flagSS=1;
	}

	if(press=='f'||press=='F')
	{
		if(1==1)
		{
		if(flagG==1)
		{
			if(flagD==2)
			{
			    flagW=1;
		        rr=rHero+1;
		        cc=cHero-2;
			}
		
		    
		    if(flagD==0 || flagD==1)
		    {
		    	flagW=2;
		        rr=rHero+1;
		        cc=cHero+2;
		    }
		    
		}
		}
		if(flagH==3)
		{
			if(flagG==1)
		{
			if(flagD==2)
			{
			    flagW=1;
		        rr=rHero+1;
		        cc=cHero-4;
			}
		
		    
		    if(flagD==0 || flagD==1)
		    {
		    	flagW=2;
		        rr=rHero+1;
		        cc=cHero+4;
		    }
		}
		}
	}

	if(press=='6')
	{
		ctH5++;
		if(ctH5%2!=0)
		{
			flagH=3;
		}
		else
		{
			flagH=0;
		}
	}


}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void movee(int &cHero, int &rHero,char press,char x[][160],int &flagH,int &ctH,int &ctH1,int &flagD,int &ctH2,int &flagG,int &flagS,int &ctH3,int &flagY,int &flagSS,int &flagW,int &rr,int &cc)
{
	if(press=='w'||press=='W')
	{
		if(x[rHero-1][cHero]==' '||x[rHero-1][cHero]=='|'||x[rHero-1][cHero]=='-')
		{
			
	     	if(x[rHero+3][cHero]!=' '||x[rHero-1][cHero]=='|'||x[rHero-1][cHero]=='-')
		    {
		     	cout<<"good";
		        if(rHero>1)
		        {
		            rHero--;
		        }
		    }
		}
	}

	if(press=='s'||press=='S')
	{
		if(flagH==0 || flagH==2)
		{
		if(x[rHero+3][cHero]==' '||x[rHero+3][cHero]=='|'||x[rHero+3][cHero]=='-')
		{
	    	if(rHero<20)
		    {
		        rHero++;
		    }
		}
		}
		if(flagH==1)
		{
			if(x[rHero+3][cHero+1]==' '||x[rHero+3][cHero+1]=='|'||x[rHero+3][cHero+1]=='-')
		{
	    	if(rHero<20)
		    {
		        rHero++;
		    }
		}  ////////***cat
		}
	}

	if(press=='d'||press=='D')
	{
		flagD=1;
		if(flagH==0||flagH==2)
		{
		   
		        if(x[rHero][cHero+3]==' '||x[rHero][cHero+3]=='|'||x[rHero][cHero+2]=='-'||x[rHero][cHero+2]=='_' || x[rHero+2][cHero+2]==' ')
		        {
		           if(cHero<77)
		           {
		               cHero++;
		           }
		        }
			
		}

		if(flagH==1)
		{
			if(x[rHero+2][cHero+3]==' '||x[rHero+2][cHero+3]=='|'||x[rHero+2][cHero+3]=='-'||x[rHero+2][cHero+3]=='_')
		        {
		           if(cHero<77)
		           {
		               cHero++;
		           }
		        }  ////////***cat
		}

		
	}

	if(press=='a'||press=='A')
	{
		flagD=2;
		if(flagH==0||flagH==2)
		{
		
		    if(x[rHero][cHero-3]==' '||x[rHero][cHero-3]=='|'||x[rHero][cHero-3]=='-')
		    {
			
		        if(cHero>2)
		        {
		            cHero--;
		        }
		    }
		
		}
		if(flagH==1)
		{
			 if(x[rHero+2][cHero-1]==' '||x[rHero+2][cHero-1]=='|'||x[rHero+2][cHero-1]=='-')
		    {
			
		        if(cHero>2)
		        {
		            cHero--;
		        }
		    }  ////////***cat
		}

		
	}

	if(press==' ')
	{
		if(flagH==0 || flagH==2)
		{
		 if(x[rHero+3][cHero]!=' '||x[rHero+3][cHero+1]!=' '||x[rHero+3][cHero-1]!=' ')
	     {
	         if(rHero>2&&x[rHero-3][cHero]==' '&&x[rHero-2][cHero]==' '&&x[rHero-1][cHero]==' ')
	         {
	             rHero-=3;
	         }

		     if(rHero>2&&x[rHero-3][cHero]!=' '&&x[rHero-2][cHero]==' '&&x[rHero-1][cHero]==' ')
	         {
	             rHero-=2;
	         } 

			if(rHero>2&&x[rHero-2][cHero]!=' '&&x[rHero-1][cHero]==' ')
	        {
	             rHero-=1;
	        }  
	    }
		}
		if(flagH==1)
		{
			if(x[rHero+3][cHero+1]!=' '||x[rHero+3][cHero+2]!=' '||x[rHero+3][cHero]!=' ')
	     {
	         if(rHero>2&&x[rHero+1][cHero+1]==' '&&x[rHero][cHero+1]==' '&&x[rHero-1][cHero+1]==' '&&x[rHero+1][cHero]==' '&&x[rHero][cHero]==' '&&x[rHero-1][cHero]==' '&&x[rHero+1][cHero-1]==' '&&x[rHero][cHero-1]==' '&&x[rHero-1][cHero-1]==' ')
	         {
	             rHero-=3;
	         }

		     if(rHero>2&&x[rHero-1][cHero+1]!=' '&&x[rHero][cHero+1]==' '&&x[rHero+1][cHero+1]==' '&&x[rHero-1][cHero]!=' '&&x[rHero][cHero]==' '&&x[rHero+1][cHero]==' '&&x[rHero-1][cHero-1]!=' '&&x[rHero][cHero-1]==' '&&x[rHero+1][cHero-1]==' ')
	         {
	             rHero-=2;
	         } 

			if(rHero>2&&x[rHero][cHero+1]!=' '&&x[rHero+1][cHero+1]==' '&&x[rHero][cHero]!=' '&&x[rHero+1][cHero]==' '&&x[rHero][cHero-1]!=' '&&x[rHero+1][cHero-1]==' ')
	        {
	             rHero-=1;
	        }  
	    }
		}
	}

	/////////////////Transformation
	if(press=='1')
	{
		ctH++;
		if(ctH%2!=0)
		{
		   flagH=1;
		}
		else
		{
			flagH=0;
		}
	}
	if(press=='2')
	{
		ctH1++;
	    if(ctH1%2!=0)
		{
			flagH=2;
		}
		else
		{
			flagH=0;
		}

	}
	if(press=='3')
	{
		ctH2++;
		if(ctH2%2!=0)
		{
			flagG=1;
		}
		else
		{
			flagG=0;
		}

	}

	

	if(press=='4')
	{
		ctH3++;
		if(ctH3%2!=0)
		{
			flagY=1;
		}
		else
		{
			flagY=0;
		}
	}

	if(press=='5')
	{
		flagSS=1;
	}

	if(press=='f'||press=='F')
	{
		
		if(flagG==1)
		{
			if(flagD==2)
			{
			    flagW=1;
		        rr=rHero+1;
		        cc=cHero-2;
			}
		
		    
		    if(flagD==0 || flagD==1)
		    {
		    	flagW=2;
		        rr=rHero+1;
		        cc=cHero+2;
		    }
		    
		}
		else
		{
			flagW=0;
		}
	}


}

////////////////////////////////////////////////////////
void setpoll(char x[][160],int & rr,int & cc,int flagW,int & flagP,int & count5,int & count6 )
{
	
	if(flagW==1)
	{
		x[rr][cc-1]='-';
		if(x[rr][cc-2]!=' ')
		{
			if(flagP==1)
			{
			x[rr][cc-1]=' ';
			}
			x[rr][cc-1]=' ';
		}
	}
	if(flagW==2)
	{
		x[rr][cc+1]='-';
		if(x[rr][cc+2]!=' '||x[rr][cc+1]=='[')
		{
			if(flagP==1)
			{
			x[rr][cc+1]=' ';
			}
			x[rr][cc+1]=' ';
		}
	}
	if((rr==9&&cc==50)||(rr==10&&cc==50)||(rr==11&&cc==50))
	{
		count5++;
	}
	if((rr==9&&cc==52)||(rr==10&&cc==52)||(rr==11&&cc==52))
	{
		count6++;
	}

}
void movepoll(char x[][160],int & flagW,int & rr,int & cc)
{
	if(flagW==1)
	{
		if(x[rr][cc-2]==' ')
		{
		cc--;
		}
	}
	if(flagW==2)
	{
		if(x[rr][cc+2]==' ')
		{
		cc++;
		}
	}


}
	//////////////////////

//////////////////////

//////////////////////
	//////////////////////
void SetWeapons(char x[][160],int &rHero,int &cHero,int &flagS)
{

	if(flagS==0)
	{
	    x[20][70]=12;
	    x[20][71]='>';
	}
	if(rHero==18 && cHero==68)
	{
		flagS=1;
		x[20][70]=' ';
		x[20][71]=' ';
	}
}

//////////////////////
void Sword_Struck(char x[][160],int &rHero,int &cHero,int flagH,int flagY,int flagSS)
{
	if(flagSS==1)
	{
	    if(flagH==2)
	    {
	    	if(flagY==1)
	    	{
	    		x[rHero+1][cHero+3]=196;
	    		x[rHero+1][cHero+4]=196;
	    		x[rHero+1][cHero+5]='>';
	    	}
	    }
		flagSS=0;
	}
}

///////////////////////
void Delete_Sword_Struck(char x[][160],int &rHero,int &cHero,int flagH,int flagY,int flagSS)
{
	if(flagSS==0)
	{
	    if(flagH==2)
	    {
	    	if(flagY==1)
	    	{
	    		x[rHero+1][cHero+5]=' ';
	    		x[rHero+1][cHero+4]=' ';
	    		x[rHero+1][cHero+3]=' ';
	    	}
	    }
		flagSS=0;
	}
}


///////////////////////
void Ground(char x[][160])
{
	for(int i=1;i<79;i++)
	{
	   x[21][i]='-';
	}	
}




//////////////////////
void MoveEnmey(int &rE, int &cE, int & place,char x[][160],int count2,int rHero)
{
	
	
	if (place == 1)	
	{
		x[rE][cE]='>';
		x[rE+1][cE+2]='>';
		x[rE+1][cE+3]='>';
		if(cE<79)
		{
	    	if (x[rE][cE+2]==' ')
		    {
			   cE++;
		    }
		}
		else
		{
			place = -1;	
		}
	}
	else	
	{
		if(count2==0)
		{
		x[rE][cE]='<';
		x[rE+1][cE-2]='<';
		x[rE+1][cE-3]='<';
		if (cE>13)
		{
			if(x[rE][cE-2]==' '&&rHero!=rE)
			{
			   cE--;
			}
		}
		else
		{
			place = 1;	
		}
		}
	}
	
}

//////////////////////
void MoveEnmey2(int &rE2, int &cE2, int & place2,char x[][160],int count3)
{
	if (place2 == 1&&count3==0)	
	{
		x[rE2][cE2]='>';
		if(cE2<14)
		{
		if (x[rE2][cE2+2]==' ')
		{
			cE2++;
		}
		}
		else
		{
			place2 = -1;	
		}
	}
	else	
	{
		if(count3==0)
		{
		x[rE2][cE2]='<';
		if (cE2>3)
		{
			if(x[rE2][cE2-2]==' ')
			{
			cE2--;
			}
		}
		else
		{
			place2 = 1;	
		}
		}
	}
}

//////////////////////
void MoveEnmey3(int &rE3, int &cE3,char x[][160],int & rr,int & cc,int & count0,int &flagP,int flagct)
{
	if((rr==3&&cc==57)||(rr==4&&cc==57)||(rr==5&&cc==57))
	{
	x[rE3][cE3] = ' ';
	x[rE3+1][cE3] = ' ';
	x[rE3+1][cE3+1] = ' ';
	x[rE3+1][cE3-1] = ' ';
	x[rE3+1][cE3-2] = ' ';
	x[rE3+1][cE3-3] = ' ';
	x[rE3][cE3-4] = ' ';
	x[rE3+1][cE3-4] = ' ';
	x[rE3+2][cE3-4] = ' ';
	x[rE3+2][cE3] = ' ';
	flagP=1;
	count0++;
	}
	if(count0==0)
	{
	x[rE3][cE3] = '<';
	x[rE3+1][cE3] = 219;
	x[rE3+1][cE3+1] = '>';
	x[rE3+1][cE3-1] = '<';
	if(flagct==1)
	{
	x[rE3+1][cE3-2] = '=';
	x[rE3+1][cE3-3] = '=';
	x[rE3][cE3-4] = '[';
	x[rE3+1][cE3-4] = '[';
	x[rE3+2][cE3-4] = '[';
	}
	x[rE3+2][cE3] = 33;
	flagP=0;
	}
}
/////////////////////
void SetEnmeyInMat(char x[][160] , int rE, int cE,int rr,int cc,int & count2 )
{
	if((rr==rE+1&&cc==cE+1)||(rr==rE+1&&cc==cE-1)||(rr==rE&&cc==cE)||(rr==rE+1&&cc==cE)||(rr==rE+2&&cc==cE)||(rr==rE+1&&cc==cE-5))
	{
	x[rE][cE] = ' ';
	x[rE+1][cE] = ' ';
	x[rE+1][cE+1] = ' ';
	x[rE+1][cE-1] = ' ';
	x[rE+2][cE] = ' ';
	count2++;
	}
	if(count2==0)
	{
	x[rE][cE] = '<';
	x[rE+1][cE] = 219;
	x[rE+1][cE+1] = '>';
	x[rE+1][cE-1] = '<';
	x[rE+2][cE] = 33;
	}
}
/////////////////
void SetEnmeyInMat2(char x[][160] , int rE2, int cE2,int rr,int cc,int & count3 )
{
	if((rr==rE2+1&&cc==cE2+1)||(rr==rE2+1&&cc==cE2-1)||(rr==rE2&&cc==cE2)||(rr==rE2+1&&cc==cE2)||(rr==rE2+2&&cc==cE2))
	{
	x[rE2][cE2] = ' ';
	x[rE2+1][cE2] = ' ';
	x[rE2+1][cE2+1] = ' ';
	x[rE2+1][cE2-1] = ' ';
	x[rE2+2][cE2] = ' ';
	count3++;
	}
	if(count3==0)
	{
	x[rE2][cE2] = '<';
	x[rE2+1][cE2] = 219;
	x[rE2+1][cE2+1] = '>';
	x[rE2+1][cE2-1] = '<';
	x[rE2+2][cE2] = 33;
	}
}

/////////////////////
void First_Game(char x[][160],int rHero,int cHero)
{
	int c1=71,c2=74;

	for (int c=1; c< 79; c++)
	{
		x[1][c] = 178;
		x[22][c] = 178;
	}

	for (int r=1; r< 23; r++)
	{
		x[r][1]  = 178;
		x[r][78] = 178;
	}
	

	/////////////
	for(int c=2;c<35;c++)
	{
	    x[17][c]=205;
	}

	x[18][34]=200;
	x[17][34]=187;
	for(int c=35;c<70;c++)
	{
	    x[18][c]=205;
	}


	//////////
	for(int r=18;r<22;r++)
	{
		x[r][c1]='|';
		x[r][c2]='|';
		x[r][72]=196;
		x[r][73]=196;
	}

	///////////
	for(int c=12;c<78;c++)
	{
	    x[13][c]=205;
	}

}

////////////////
void Sec_Game(char x[][160],int rHero,int cHero,int ct,int count5,int count6)
{
	int c,r;
	for (int c=1; c< 10; c++)
	{
		x[21][c] = 178;
		x[22][c] = 178;
	}
	
	for (int c=63; c< 79; c++)
	{
		x[21][c] = 178;
		x[22][c] = 178;
	}

	
}
////////////////
void Transporter1(char x[][160],int rTrans1,int cTrans1)
{

	x[rTrans1+1][cTrans1-1]='=';
	x[rTrans1+1][cTrans1]='=';
	x[rTrans1+1][cTrans1+1]='=';
}

////////////////
void MoveHeroT1(int &rHero, int &cHero, int & dir1,int dir)
{
	if(dir==1)
	{
		dir1=1;
	}
	else
	{
		dir1=-1;
	}
	if (dir1 == 1)	

	{
		if (cHero < 78)
		{
			cHero++;
		}
		else
		{
			dir1 = -1;	
		}
	}
	else	
	{
		if (cHero>2)
		{
			cHero--;
		}
		else
		{
			dir1 = 1;	
		}
	}

}
void MoveTrans1(char x[][160],int &rTrans1,int &cTrans1,int &flag1)
{	
	
	
	if (flag1 == 1)	
	{
		if(cTrans1<64)
		{
		
			cTrans1++;
		}
		else
		{
			flag1 = -1;	
		}
	}
	else	
	{
		if (cTrans1>8)
		{
			if(x[rTrans1][cTrans1-2]==' ')
			{
		    	cTrans1--;
			}
		}
		else
		{
			flag1 = 1;	
		}
	}
	
}
////////////////////////
void MoveTrans2(char x[][160],int &rTrans2,int &cTrans2,int &flag2,int &flag22)
{
	if (flag2 == 1)	
	{
		if(cTrans2<35&&rTrans2==1)
		{
		
			cTrans2++;
		}
		else
		{
			flag2=0;
		
		}
	}
	if(flag2==0)               
	{
			if(cTrans2>29&&rTrans2==1)
		{
		
			cTrans2--;
		}
		else
		{
			flag2=3;
		
		}
	}
	if(flag2==3)         //////////t7t
	{
			if(rTrans2<7)
		{
			rTrans2++;
		}
		else
		{
			flag2=4;
		
		}
	
	}
	if(flag2==4)         //////////foooooooo2
	{
		if(rTrans2>1)
		{
		
			rTrans2--;
		}
		else
		{
			flag2=1;
		
		}
	
	}
}
void MoveHeroT2(char x[][160],int &rHero,int &cHero,int &flag2,int &flag22)
{
	if (flag2 == 1)	
	{
		if(cHero<35&&rHero==3)
		{
			flag22=0;
		
			cHero++;
		}
		else
		{
			flag2=0;
		flag22=1;
		}
	}
	if(flag2==0)               
	{
		if(cHero>29&&rHero==3)
		{
		
			cHero--;
		}
		else
		{
			flag2=3;
		
		}
	}
	if(flag2==3)         
	{
		if(rHero<9)
		{
			rHero++;
		}
		else
		{
			flag2=4;
		
		}
	
	}
	if(flag2==4)         
	{
			if(rHero>3)
		{
		
			rHero--;
		}
		else
		{
			flag2=1;
		
		}
	
	}
}
////////////////
void Transporter2(char x[][160],int rTrans2,int cTrans2)
{
	x[rTrans2][cTrans2]=25;
	x[rTrans2+1][cTrans2-1]='=';
	x[rTrans2+1][cTrans2]='=';
	x[rTrans2+1][cTrans2+1]='=';

	
}
void setpool(char x[][160],int & rrr,int & ccc,int rHero,int cHero,int  & count,int & H)
{
	x[rrr][ccc]='=';
	x[rrr+1][ccc]='=';
	x[rrr+2][ccc]='=';
	if(x[rrr][ccc-2]!=' '||x[rrr+1][ccc-2]!=' '||x[rrr+2][ccc-2]!=' ')
		{
			x[rrr][ccc]=' ';
			x[rrr+1][ccc]=' ';
			x[rrr+2][ccc]=' ';
			if(rHero-1==rrr||rHero==rrr||rHero+1==rrr||rHero-1==rrr+1||rHero==rrr+1||rHero+1==rrr+1||rHero-1==rrr+2||rHero==rrr+2||rHero+1==rrr+2)
			{
				if(count>0)
				{
				H-=50;
				}
				count++;
			}
			rrr=3;
			ccc=58;
		}
}
void movepool(char x[][160],int & rrr,int & ccc)
{
	if(x[rrr][ccc-2]==' '&&x[rrr+1][ccc-2]==' '&&x[rrr+2][ccc-2]==' ')
		{
	       ccc--;
	    }
}
void bullets(int cHero,int rHero,char press,char x [][160], int rarr[200],int carr[200],int &ctarr,int arr[200],int flagD)
{
	
	if(press=='p'&&flagD==1)
	{
		rarr[ctarr]=rHero+1;
		carr[ctarr]=cHero+3;
		arr[ctarr]=0;//emeeeeen
		ctarr++;
	}
	if(press=='p'&&flagD==2)
	{
		rarr[ctarr]=rHero+1;
		carr[ctarr]=cHero-3;
		ctarr++;
		arr[ctarr]=1;//shemaaaaaaaaal
	}
}

void Game_over(int &flagGameOver)
{
	char A;
	  cout<< "          _____                            ____                    " <<endl; 
      cout<< "         / ____|                          / __ \\                   " <<endl;
      cout<< "        | |  __  __ _ _ __ ___   ___     | |  | |_   _____ _ __    " <<endl;
      cout<< "        | | |_ |/ _. | ._ . _ \\ / _ \\    | |  | \\ \\ / / _ \\ .__|   " <<endl;
      cout<< "        | |__| | (_| | | | | | |  __/    | |__| |\\ \V /  __/ |      " <<endl;
      cout<< "         \\_____|\\__,_|_| |_| |_|\\___|     \\____/  \\_/ \\___|_|      " <<endl;

	  cout<<endl<<endl<<endl;
	  cout<<"Do you want to play again ? Y\\N"<<endl;
	  cin>>A;
	  if(A=='Y')
	  {
		  flagGameOver=1;
	  }
}

/////////////////the Video game
void two_Heros(char x[][160],int &rHero1,int &cHero1,int &rHero2,int &cHero2,int &flag2H)
{
	if(flag2H==0)
	{
	////1st
	x[rHero1][cHero1] = 'O';
	x[rHero1+1][cHero1-1] ='/'; 
	x[rHero1+1][cHero1] ='|';
	x[rHero1+1][cHero1+1] = '\\';
	x[rHero1+2][cHero1-1] = '/';
	x[rHero1+2][cHero1+1] = '\\';

	///2sd
	x[rHero2][cHero2] = 'O';
	x[rHero2+1][cHero2-1] ='/'; 
	x[rHero2+1][cHero2] ='|';
	x[rHero2+1][cHero2+1] = '\\';
	x[rHero2+2][cHero2-1] = '/';
	x[rHero2+2][cHero2+1] = '\\';
	////cHero1=62,cHero2=58;
	if(cHero1<62)
	{
	   cHero1++;
	}
	if(cHero2<58)
	{
	  cHero2++;
	}
	}
}
////////////////

void Helicopter(char x[][160],int &rCopter,int cCopter,int &flagCopter)
{
	if(flagCopter==1)
	{
	  x[rCopter][cCopter]='*';
	  x[rCopter][cCopter+1]='>';
	  x[rCopter][cCopter+2]='=';
	  x[rCopter][cCopter+3]='=';
	  x[rCopter][cCopter+4]='=';
	  x[rCopter][cCopter+5]='=';
	  x[rCopter][cCopter+6]='=';
	  x[rCopter][cCopter+7]='[';
	  x[rCopter][cCopter+8]='_';
	  x[rCopter][cCopter+9]=']';
	  x[rCopter][cCopter+10]=192;
	  x[rCopter][cCopter+11]=')';
	  x[rCopter-1][cCopter+3]='-';
	  x[rCopter-1][cCopter+4]='-';
	  x[rCopter-1][cCopter+5]='-';
	  x[rCopter-1][cCopter+6]='-';
	  x[rCopter-1][cCopter+7]='-';
	  x[rCopter-1][cCopter+8]='|';
	  x[rCopter-1][cCopter+9]='-';
	  x[rCopter-1][cCopter+10]='-';
	  x[rCopter-1][cCopter+11]='-';
	  x[rCopter-1][cCopter+12]='-';
	  x[rCopter-1][cCopter+13]='-';
	  x[rCopter+1][cCopter+7]='`';
	  x[rCopter+1][cCopter+9]='`';
	  x[rCopter+1][cCopter+6]='-';
	  x[rCopter+1][cCopter+8]='-';
	  x[rCopter+1][cCopter+10]='-';
	}
}

void Move_Helicopter(int cHero1,int &cCopter,int &flagCopter)
{
		
		if(cCopter+15<80)
		{
			cCopter++;
		}
		else
		{
			flagCopter=0;
		}

}
////////////////
void yy(char y[][160])
{
	for(int c=0;c<160;c++)
	{
		y[20][c]=235;
	}
}
////////////////
void tree(char y[][160],int &tc,int&tr, int ch)
{
	y[tr][tc]='*';
	y[tr+1][tc-1]='/';
	y[tr+1][tc+1]='\\';
	y[tr+2][tc-2]='/';
	y[tr+2][tc+2]='\\';


	y[tr+3][tc-1]=31;
	y[tr+3][tc+1]=31 ;
	y[tr+3][tc-1]=31;
	y[tr+3][tc]=31;
	y[tr+4][tc]='|';
	//y[tr+5][tc]='|';
	if(tc==0||tc<ch)
	{
		tc=ch+78;
	}
	else
	{
		tc--;
	}
}
///////////////
void sety(char y[][160])
{
	for(int r=0;r<24;r++)
	{
		for(int c=0;c<160;c++)
		{
			y[r][c]=' ';
		}
	}


	int r=0;
	for(int c=0;c<160;c++)
	{
		y[0][c]=158;
		y[21][c]=236;
		
	}





}
///////////////
void chiken(char y[][160],int &cch,int &rch, int &heal)
{

	y[rch-1][cch]='O';
	y[rch][cch]='-';
	y[rch+1][cch-1]='/';
	y[rch+1][cch+1]='\\';
	y[rch+2][cch-2]='|';
	y[rch+2][cch+2]='|';
	
	y[rch+3][cch-1]='\\';
	y[rch+3][cch+1]='/';
	y[rch+4][cch]='-';
	
	
	y[rch+5][cch+1]='|';
	y[rch+5][cch-1]='|';
	

}

void movechicken(int &cch,int &rch,int &flag)
{
	
	if(flag==0)
	{
		if(rch+1<18)
		{
		rch++;
		}
		else
		{
			flag=1;
		}
	}


	if(flag==1)
	{
		if(cch+1<155&&rch-1>5)
		{
			cch+=4;
			rch--;
		}
		else
		{
			flag=2;
		}
	}
	
	

	if(flag==2)
	{
		if(rch+1<20)
		{
			rch++;
		}
		else
		{
			flag=3;
		}
	}


	if(flag==3)
	{

		if(cch-1>85&&rch-1>5)
		{
			cch-=4;
			rch--;
		}
		else
		{
			flag=0;
		}

	}
}
////////
void BigHero(char x[][160],int &rHero,int &cHero,int &rHero1,int &cHero1,int &rHero2,int &cHero2,int &flagH,int &flag2H)
{
	if(rHero==16 && cHero==60)
	{
		rHero=17;
		flag2H=1;
		flagH=4;
	
	}
}

///////////////
void coout80(char x[][160])
{
	system("cls");
	for(int r=0;r<24;r++)
	{
		for(int c=0;c<80;c++)
		{
			cout<<x[r][c];
		}
	}
}
void main()
{
	///17-7
	///3-77
	//18-54
	int scroll=0;
	int cch1=100,rch1=20,rch=7,cch=81,flagch=0,flagch1=0,heal1=2,heal2=2;

	char y[24][160];
		int arr[200],rarr[200],carr[200],ctarr=0;//bullets
	int flagH3,rCopter=5,cCopter=2,flagJump=0;
	int ctt=0,ctt2=0,flagct=1,aaa=12;
	char press,L=3;
	char x[24][160];
	int rE=5,cE=13,rE2=12,cE2=3,rE3=3,cE3=60,rHero=17,flag=1,cHero=7,rTrans1=16,cTrans1=65,rTrans2=1,cTrans2=29,flagH=0,ctH=0,ctH1=0,ctH3=0;
	int c1=20,c2=17,ct=0,flag1=0,flag2=0,flag22=1,place =1,place2=0,dir=1,dir1,dir2=1,dir3=1,flagD=2,ctH2=0,flagG=0,flagS=0,flagY=0,flagW=0,count=0,flagP=0,count2=0,count3=0,count5=0,count6=0,count7=0,rrr=3,ccc=58;
	int ctW=0,flagSS=0,cc=0,rr=0,ctH5=0,flagSquatting=0,H=100,i=0,NumLife=5,flagMap=1,flagGameOver=5,flagVideo=1,rHero1=18,cHero1=48,rHero2=18,cHero2=44,rrrr=rHero,cccc=cHero,count0=0;
	int tc1=0,tr1=15,tc2=20,tr2=15,tc3=40,tr3=15,tc4=77,tr4=15,counter=0,flag2H=0,cpMap=0,flagCopter=1;
	////////////////////////////////////


	for(;;)
	{
	/////////////////////////////					game soliman begining
	if(flagMap==1)
	{
	for (;;)
	{
		for(; !kbhit() ; )  
		{
			counter++;
			
			sety(y);
			yy(y);
			
			
				tree(y,tc4,tr4,cHero);
			
			
			if(tc1>=0)
			{
			tree(y,tc1,tr1,cHero);
			}
			if(tc2>=0)
			{
			tree(y,tc2,tr2,cHero);
			}
			if(tc3>=0)
			{
			tree(y,tc3,tr3,cHero);
			}

			Hero(y, rHero, cHero,flagH,flagD,flagG,flagS,flagY);
			gravity(cHero,rHero,y,flagH,flag22);
			if(y[rHero][cHero+2]!=' ')
			{
				H=0;
			}
			cout<<" Health"<<" "<<H<<"                                                        ";
			if(H==0)
			{
				H=100;
				NumLife--;
			}
			cout<<"Life"<<" ";
			for(i=0;i<NumLife;i++)
			{
				cout<<L;
			}
			cout_screen(y,cHero);
			if(NumLife==0)
		{
			cpMap=flagMap;
			flagMap=0;
			break;
		}

		}
		char press=getch();

		if(flagMap ==0)
		{
			flagMap=0;
			break;
		}
		if(press=='5'||cHero==119 )
		{
			flagMap=5;
			break;
		}
		cout<<'\b';
		move(cHero,rHero,press,y,flagH,ctH,ctH1,flagD,ctH2,flagG,flagS,ctH3,flagY,flagSS,flagW,rr,cc,ctH5,0);
	}
	//////////////////////////////					end of soliman code

	/////////////////////////////////

	}

	////////////
  if(flagMap==5)
  {
	 rHero=rCopter+2;cHero=cCopter+8;
      for (;;)
	  {
		  for(; !kbhit() ; )
		  {
			  if(cHero==35&&rHero==4)
			{
				aaa=1;
			
			}
			if(aaa==1)
			{
			ctt++;
			if(ctt%2==0)
			{
				ctt2++;
				if(ctt2%2==0)
				{
					flagct=1;
				}
			}
			else
			{
				flagct=0;
			}
			}
			if(x[rHero+3][cHero]==' ')
			{
				if(cHero!=29||rHero!=3)
				{
				gravity(cHero,rHero,x,flagH,flag22);
				}
			}
			if(rHero==3&&cHero==35)
			{
				rHero++;
			}
			if(flagct==1&&aaa==1)
			{
				count7=1;
			}
			Mat(x);
			Ground(x);
			x[21][67]=179;
			x[20][67]=179;
			x[19][67]='+';
			x[19][66]='-';
			x[19][68]='-';
			x[18][67]=179;

			/////words
			x[16][66]='M'; 
			x[16][67]='T';
			x[16][68]='R';


			
			Move_Helicopter(cHero1,cCopter,flagCopter);
			Helicopter(x,rCopter,cCopter,flagCopter);
			
		  
			///if(flagJump==1)
			BigHero(x,rHero,cHero,rHero1,cHero1,rHero2,cHero2,flagH,flag2H);
			Hero(x,rHero,cHero,flagH,flagD,flagG,flagS,flagY);
			two_Heros(x,rHero1,cHero1,rHero2,cHero2,flag2H);
			setpoll(x,rr,cc,flagW,flagP,count5,count6);
			movepoll(x,flagW,rr,cc);
			if(flagG==1&&flagD==1)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==0)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				if(x[rarr[nn]][carr[nn]+1]==' '&&x[rarr[nn]][carr[nn]+2]==' '&&x[rarr[nn]][carr[nn]+3]==' '&&carr[nn]+3<79)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]+=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
				}
			}




			if(flagG==1&&flagD==2)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==1)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
				x[rarr[nn]][carr[nn]-5]='-';
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				int cr,cc;
				cr=rarr[nn];
				cc=carr[nn];
				if(x[cr][cc-1]==' '&&x[cr][cc-2]==' '&&x[cr][cc-3]==' '&&carr[nn]-3>0)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]-=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
				}
			}







			if(x[rHero-1][cHero]=='='&&rHero==18)
			{
				MoveHeroT1(rHero,cHero,dir1,dir);
			}
			if(x[rHero-1][cHero]=='='&&rHero!=18)
			{
				MoveHeroT2(x,rHero,cHero,dir2,dir3);
			}
			if(flagP!=1)
			{
			if(count7==1&&aaa==1)
			{
				setpool(x,rrr,ccc,rHero,cHero,count,H);
			}
			if(count7==1&&aaa==1)
			{
				movepool(x,rrr,ccc);
			}
			}
			cout<<" Health"<<" "<<H<<"                                                        ";
			if(H==0)
			{
				rHero=rrrr;
				cHero=cccc;
			}
			if(H==0)
			{
				H=100;
				NumLife--;
			}
			cout<<"Life"<<" ";
			for(i=0;i<NumLife;i++)
			{
				cout<<L;
			}
			cout<<endl;
			cout_screen(x,cHero);
		  }
		  char press=getch();
		if(H==0)
		{
			H=100;
		}
		if(NumLife==0)
	    	{
	    		flagMap=2;
				break;
	    	}
		cout<<'/a';
		bullets(cHero,rHero,press,x, rarr,carr,ctarr,arr,flagD);
	move(cHero,rHero,press,y,flagH,ctH,ctH1,flagD,ctH2,flagG,flagS,ctH3,flagY,flagSS,flagW,rr,cc,ctH5,0);
	if(cHero==64||press=='5')
			{
				flagMap=2;
				break;
			}
	  }
  }
	cHero=7;


	if(flagMap==2)
	{
		flagH=0;
	for (;;)
	{
		for(; !kbhit() ; )
		{
			if(cHero==35&&rHero==4)
			{
				aaa=1;
			
			}
			if(aaa==1)
			{
			ctt++;
			if(ctt%2==0)
			{
				ctt2++;
				if(ctt2%2==0)
				{
					flagct=1;
				}
			}
			else
			{
				flagct=0;
			}
			}
			if(x[rHero+3][cHero]==' ')
			{
				if(cHero!=29||rHero!=3)
				{
				gravity(cHero,rHero,x,flagH,flag22);
				}
			}
			if(rHero==3&&cHero==35)
			{
				rHero++;
			}
			if(flagct==1&&aaa==1)
			{
				count7=1;
			}
			Mat(x);
			Sec_Game(x,rHero,cHero,ct,count5,count6);
			Transporter1(x,rTrans1,cTrans1);
			//Transporter2(x,rTrans2,cTrans2);
			SetEnmeyInMat(x,rE,cE,rr,cc,count2);
			MoveEnmey(rE,cE, place,x,count2,rHero);
			SetEnmeyInMat2(x,rE2,cE2,rr,cc,count3);
			MoveEnmey2(rE2,cE2,place2,x,count3);
			MoveEnmey3(rE3,cE3,x,rr,cc,count0,flagP,flagct);
			SetWeapons(x,rHero,cHero,flagS);
			Sword_Struck(x,rHero,cHero,flagH,flagY,flagSS);
			Delete_Sword_Struck(x,rHero,cHero,flagH,flagY,flagSS);
			Hero(x,rHero,cHero,flagH,flagD,flagG,flagS,flagY);
			cout<<rHero<<endl<<cHero;
		    Hero_Damage(x,rHero,cHero,H);
			MoveTrans1(x,rTrans1,cTrans1,flag1);
			MoveTrans2(x,rTrans2,cTrans2,flag2,flag22);
			setpoll(x,rr,cc,flagW,flagP,count5,count6);
			movepoll(x,flagW,rr,cc);
			if(flagG==1&&flagD==1)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==0)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				if(x[rarr[nn]][carr[nn]+1]==' '&&x[rarr[nn]][carr[nn]+2]==' '&&x[rarr[nn]][carr[nn]+3]==' '&&carr[nn]+3<79)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]+=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
			  }
			}




			if(flagG==1&&flagD==2)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==1)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
				x[rarr[nn]][carr[nn]-5]='-';
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				int cr,cc;
				cr=rarr[nn];
				cc=carr[nn];
				if(x[cr][cc-1]==' '&&x[cr][cc-2]==' '&&x[cr][cc-3]==' '&&carr[nn]-3>0)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]-=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
				}
			}


		




			if(x[rHero-1][cHero]=='='&&rHero==18)
			{
				MoveHeroT1(rHero,cHero,dir1,dir);
			}
			if(x[rHero-1][cHero]=='='&&rHero!=18)
			{
				MoveHeroT2(x,rHero,cHero,dir2,dir3);
			}
			if(flagP!=1)
			{
			if(count7==1&&aaa==1)
			{
				setpool(x,rrr,ccc,rHero,cHero,count,H);
			}
			if(count7==1&&aaa==1)
			{
				movepool(x,rrr,ccc);
			}
			}
			cout<<" Health"<<" "<<H<<"                                                        ";
			if(H==0)
			{
				rHero=rrrr;
				cHero=cccc;
			}
			if(H==0)
			{
				H=100;
				NumLife--;
			}
			cout<<"Life"<<" ";
			for(i=0;i<NumLife;i++)
			{
				cout<<L;
			}
			if(scroll==1)
			{
			cout_screen(x,cHero);
			}

			if(scroll==0)
			{
				coout80(x);
			}

			if(rHero==5&&cHero==30)
			{
				scroll=1;
			}

		}
		char press=getch();
		if(H==0)
		{
			H=100;
		}
		if(NumLife==0)
	    	{
				cpMap=flagMap;
	    		flagMap=0;
				break;
	    	}
		bullets(cHero,rHero,press,x, rarr,carr,ctarr,arr,flagD);
	movee(cHero,rHero,press,x,flagH,ctH,ctH1,flagD,ctH2,flagG,flagS,ctH3,flagY,flagSS,flagW,rr,cc);
	if(press=='5')
			{
				flagMap=4;
				break;
			}
	}
 }

	if(flagMap==0)
   {
	   NumLife=5;
       for (;;)
	    {
		    for(; !kbhit() ; )
		    {
				system("CLS");
				Game_over(flagGameOver);
			   if(flagGameOver==1)
			   {
				   flagMap=cpMap;
				   break;
			   }
		       
		    }
			break;
	    }
	}
	  
  if(flagMap==4)
	{

	for (;;)
	{
		for(; !kbhit() ; )  
		{

			sety(y);
			if(heal2!=0)
			{
			chiken(y,cch,rch,heal2);
			}

			if(y[rch+6][cch]=='-');
			{
				heal1--;
			}
			if(y[rch1+6][cch1]=='-');
			{
				heal2--;
			}


			Hero(y, rHero, cHero,flagH,flagD,flagG,flagS,flagY);
			gravity(cHero,rHero,y,flagH,flag22);
			movechicken(cch,rch,flagch);
			if(heal1!=0)
			{
			chiken(y,cch1,rch1,heal1);
			}
			movechicken(cch1,rch1,flagch1);
			cout_screen(y,cHero);
		
		SetWeapons(x,rHero,cHero,flagS);
			//Sword_Struck(x,rHero,cHero,flagH,flagY,flagSS);
			//Delete_Sword_Struck(x,rHero,cHero,flagH,flagY,flagSS);
			Hero(x,rHero,cHero,flagH,flagD,flagG,flagS,flagY);
		    Hero_Damage(x,rHero,cHero,H);
			MoveTrans1(x,rTrans1,cTrans1,flag1);
			MoveTrans2(x,rTrans2,cTrans2,flag2,flag22);
			setpoll(x,rr,cc,flagW,flagP,count5,count6);
			movepoll(x,flagW,rr,cc);
			if(flagG==1&&flagD==1)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==0)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				if(x[rarr[nn]][carr[nn]+1]==' '&&x[rarr[nn]][carr[nn]+2]==' '&&x[rarr[nn]][carr[nn]+3]==' '&&carr[nn]+3<79)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]+=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
			  }
			}




			if(flagG==1&&flagD==2)
			{
			for(int nn=0;nn<ctarr;nn++)
			{
				if(arr[nn]==1)
				{
				x[rarr[nn]][carr[nn]]='_';
				}
				x[rarr[nn]][carr[nn]-5]='-';
			}
			for(int nn=0;nn<ctarr;nn++)
			{
				int cr,cc;
				cr=rarr[nn];
				cc=carr[nn];
				if(x[cr][cc-1]==' '&&x[cr][cc-2]==' '&&x[cr][cc-3]==' '&&carr[nn]-3>0)
				{
					if(carr[nn]!=-1)
					{
						carr[nn]-=3;
					}
				}
				else
				{
					x[rarr[nn]][carr[nn]]=' ';
					carr[nn]=-1;
				}
				}
			}




			rrrr=rHero;
			cccc=cHero;


			if(x[rHero-1][cHero]=='='&&rHero==18)
			{
				MoveHeroT1(rHero,cHero,dir1,dir);
			}
			if(x[rHero-1][cHero]=='='&&rHero!=18)
			{
				MoveHeroT2(x,rHero,cHero,dir2,dir3);
			}
			if(flagP!=1)
			{
			if(count7==1&&aaa==1)
			{
				setpool(x,rrr,ccc,rHero,cHero,count,H);
			}
			if(count7==1&&aaa==1)
			{
				movepool(x,rrr,ccc);
			}
			}
			cout<<" Health"<<" "<<H<<"                                                        ";
			if(H==0)
			{
				H=100;
				NumLife--;
			}
			cout<<"Life"<<" ";
			for(i=0;i<NumLife;i++)
			{
				cout<<L;
			}
			
		
		
		
		
		
		}
		char press=getch();
		if(press=='5')
		{
			flagMap=6;
			break;
		}
		
		cout<<'\b';
		int r=0;
		move(cHero,rHero,press,y,r,ctH,ctH1,flagD,ctH2,flagG,flagS,ctH3,flagY,flagSS,flagW,rr,cc,ctH5,0);
	}

	if(flagMap=6)
	{
      system("CLS");
	       
	       cout<<"                                                                            "<<endl;
		   cout<<"                                                                            "<<endl;
		   cout<<"                                                                            "<<endl;
           cout<<"         _    _ _                         _    _ _                          "<<endl;
           cout<<"        | |  | (_)                       | |  | (_)                         "<<endl;
           cout<<"        | |  | |_ _ __  _ __   ___ _ __  | |  | |_ _ __  _ __   ___ _ __    "<<endl;
           cout<<"        | |/\\| | | '_ \\| '_ \\ / _ \\ '__| | |/\\| | | '_ \\| '_ \\ / _ \\ '__|   "<<endl;
           cout<<"        \\  /\\  / | | | | | | |  __/ |    \\  /\\  / | | | | | | |  __/ |      "<<endl;
           cout<<"         \\/  \\/|_|_| |_|_| |_|\\___|_|     \\/  \\/|_|_| |_|_| |_|\\___|_|      "<<endl;
           cout<<"                                                                            "<<endl;
           cout<<"                                                                            "<<endl;
           cout<<"         _____ _     _      _               ______ _                        "<<endl;
           cout<<"        /  __ \\ |   (_)    | |              |  _  (_)                       "<<endl;
           cout<<"        | /  \\/ |__  _  ___| | _____ _ __   | | | |_ _ __  _ __   ___ _ __  "<<endl;
           cout<<"        | |   | '_ \\| |/ __| |/ / _ \\ '_ \\  | | | | | '_ \\| '_ \\ / _ \\ '__| "<<endl;
           cout<<"        | \\__/\\ | | | | (__|   <  __/ | | | | |/ /| | | | | | | |  __/ |    "<<endl;
           cout<<"         \\____/_| |_|_|\\___|_|\\_\\___|_| |_| |___/ |_|_| |_|_| |_|\\___|_|    "<<endl;
                                                                                         
                                                                     
	}	


	}
  
	}

	
system("pause");

}



